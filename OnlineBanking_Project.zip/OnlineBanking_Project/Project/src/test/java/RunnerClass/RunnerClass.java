package RunnerClass;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
 features = "FeatureFiles/RapidTest.feature"
 ,glue = {"StepDef"}
 //plugin = { "pretty","html:target/cucumber-reports" }
,plugin ={"com.cucumber.listener.ExtentCucumberFormatter:C:\\Users\\RM MANI\\Downloads\\SUMMERCAMP-Online Training-Maveric\\Selenium\\Project\\Project\\ExtentReport\\ReportFile.html"}
//,tags = "@negative1"
// @positive,@negative
 )
 
public class RunnerClass 
{
 
}
