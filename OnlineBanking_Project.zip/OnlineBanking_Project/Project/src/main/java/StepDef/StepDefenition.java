package StepDef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import RapidCode.CodeRapid;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;


public class StepDefenition extends CodeRapid
{
	CodeRapid code =new CodeRapid();
	
	@Given("^I have url$")
	public void i_have_url()  
	{
		code.url();
	}

	@When("^I enter the login credentails$")
	public void i_enter_the_login_credentails()  
	{    
		code.loginCredentails();
	}

	@And("^Click the fund transfer tab$")
	public void click_the_fund_transfer_tab()  
	{   
	    code.fundTab();
	}

	@And("^Fill fund transfer details$")
	public void fill_fund_transfer_details()  
	{
	    code.fundDetails();
	}

	@And("^Click the fund transfer submit button$")
	public void click_the_fund_transfer_submit_button()  
	{
	    code.fundSubmit();
	}

	@And("^Enter the authorization code$")
	public void enter_the_authorization_code()  
	{
	    code.fundAuthCode();   
	}
	@And("^Able to see the successfull fund transfer page$")
	public void able_to_see_the_successfull_fund_transfer_page()  
	{
	    code.fundSuccess(); 
	}
	@And("^Click the Account Summary tab$")
	public void accontSummary() 
	{
	    code.getaccountSummary();
	}
	@And("^Click Account statement tab$")
	public void accontStatement()  
	{
	    code.getAccountStatement();
	}
	@And("^Click the Account Details tab$")
	public void accontDetails()  
	{
	    code.getAccountDetails();
	}
	@Then("^signout from application$")
	public void signoutApplication()  
	{
	    code.signout();
	    code.close();
	}
	@When("^I enter the (.*?) and (.*?)$")
	public void invalidData(String s1,String s2)
	{
		code.invalidCred(s1, s2);
	}
	@And("^I click Login button$")
	public void login()
	{
		code.invalidLogin();
	}
	@Then("^I getting an error message$")
	public void errorMessage() throws Exception
	{
		code.errorMessages();
		code.close();
	}
	@When("^I click the register now$")
	public void registerNow()
	{
		code.regiButton();
	}
	@And("^I fill the registeration details$")
	public void registerDetail()
	{
		code.registerDetails();
	}
	@And("^I click the register now button$")
	public void registerButton() throws Exception
	{
		code.regiConfirmButton();
	}
	@Then("^I able to register my account$")
	public void registeracount() throws Exception
	{
		code.registerError();
		code.close();
	}
}
