package Driver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PropertyFile.PropertyFile;

public class DriverClass 
{
	protected static WebDriver driver;
	public void launch()
	{
		String dirpath = System.getProperty("user.dir");
		String browsername =PropertyFile.getValue("browser");
		System.out.println("name:"+browsername);
		switch(browsername)
		{
		case "chrome": 
			System.setProperty("webdriver.chrome.driver", dirpath+"\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();			
			break;
		case "firefox":
			System.setProperty("webdriver.gecko.driver", dirpath+"\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			break;
			default:
				System.out.println("Browser type invalid");
				break;
		}
	}
}
