package RapidCode;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Driver.DriverClass;
import Elements.Xpath;
import PropertyFile.PropertyFile;



public class CodeRapid extends DriverClass
{
	static String path = System.getProperty("user.dir");

	public static void sendkey(String str1, String str2)
    {
        WebElement web = driver.findElement(By.xpath(str1));
        web.sendKeys(str2);
    }
    public static void click(String str1)
    {
        WebElement web = driver.findElement(By.xpath(str1));
        web.click();
    }
    public static String getText(String str1)
    {
        WebElement web = driver.findElement(By.xpath(str1));
        return web.getText();
    }
    public static void screenshot(String s)
	{
		try {
		String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
		TakesScreenshot screen =((TakesScreenshot)driver);
		File SrcFile=screen.getScreenshotAs(OutputType.FILE);
		File despath = new File(path+"/Screenshots/"+s+timestamp+".jpg");
		FileUtils.copyFile(SrcFile, despath);
		} catch (IOException e) 
		{
			e.printStackTrace();
		}	
	}
    
	public void url()
	{
		launch();
		driver.get(PropertyFile.getValue("url"));
		screenshot("launch");
	}
	public void loginCredentails()
	{
		sendkey(Xpath.username(),PropertyFile.getValue("username"));
		sendkey(Xpath.password(),PropertyFile.getValue("password"));
		screenshot("login Credentails");
		click(Xpath.submitButton());
		sendkey(Xpath.accPin(),PropertyFile.getValue("accountPin"));
		screenshot("pin number");
		click(Xpath.submitButton());
		
		String s1 = getText(Xpath.welcomText());
		System.out.println(s1);
		String s2 ="Welcome, TOUSIF KHAN";
		Assert.assertEquals(s2, s1);
		
	}
	public void signout()
	{
		click(Xpath.signOutButton());
		screenshot("signout page");
	}
	public void close()
	{
		driver.quit();
	}
	public void fundTab()
	{
		click(Xpath.fundTabButton());
		screenshot("fundtab page");
	}
	public void fundDetails()
	{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,250);");
			sendkey(Xpath.reciverbankName(),PropertyFile.getValue("ReceiverBankName"));
			sendkey(Xpath.reciverName(),PropertyFile.getValue("ReceiverName"));
			sendkey(Xpath.reciverAccnt(),PropertyFile.getValue("ReceiverAccntNo"));
			sendkey(Xpath.swiftNumber(),PropertyFile.getValue("Swift"));
			sendkey(Xpath.fundAmount(),PropertyFile.getValue("Amount"));
			Select dropdown = new Select(driver.findElement(By.id("toption")));
			dropdown.selectByIndex(3);
			DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
			Date date = new Date();
			String date1= dateFormat.format(date);
			sendkey(Xpath.dateTransfer(),date1);
			screenshot("fund details page");
			sendkey(Xpath.fundDescription(),"FundTransfer");
	}
	public void fundSubmit()
	{
		click(Xpath.submitButton());
	}
	public void fundAuthCode()
	{
		sendkey(Xpath.fundToken(),PropertyFile.getValue("token"));
		screenshot("fund authcode page");
		click(Xpath.submitButton());
	}
	public void fundSuccess()
	{
		String s1 = getText(Xpath.welcomText());
		screenshot("fund Success page");
		String s2 = "International Transaction Successful";
		System.out.println("Get Text :"+s1);
		if(s1.contains("Successful"))
		{
			System.out.println("Success Message : International Transaction Successful");
		}
		else
		{
			System.out.println("International Transaction Failed");
		}
		Assert.assertEquals(s2, s1);
	}
	
	public void getaccountSummary()
	{
	    try {
			click(Xpath.summaryTab());
			Thread.sleep(3000);
			String s1=getText(Xpath.welcomText());
			String s2="Welcome, TOUSIF KHAN";
			Assert.assertEquals(s2,s1);
			System.out.println("Account Summary Page Loaded Successfully");
			screenshot("account statement page");
		} catch (Exception e) {
			System.out.println("Account Summary Page not loaded"+e);
		}				   	
	}
	public void getAccountStatement()
	{
		try {
			click(Xpath.statementTab());
			Thread.sleep(3000);
			String s1=getText(Xpath.welcomText());
			String s2="Account Statement";
			Assert.assertEquals(s2,s1);
			System.out.println("Account Statement Page Loaded Successfully");
			List<WebElement>  col = driver.findElements(By.xpath(Xpath.statementColumn()));  
			System.out.println("No of cols are : " +col.size());
			for (WebElement c : col) {
			    System.out.print(c.getText() + "\t");
			}
			List<WebElement>  rows = driver.findElements(By.xpath(Xpath.statementRow()));
			System.out.println("No of rows are : " + rows.size());
			String  data = driver.findElement(By.xpath(Xpath.rowText())).getText();
			System.out.println("data is : " + data);
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,250);");
			screenshot("account summary page");
		} catch (Exception e) {
			System.out.println("Account Statement Page not loaded"+e);
		}	
	}
    public void getAccountDetails()
    {
		try {
			click(Xpath.AccountDetailsTab());
			Thread.sleep(3000);
			String s1 = getText(Xpath.AccountDetailsText());
			String s2 ="User Account Details";
			Assert.assertEquals(s2, s1);
			System.out.println("Account Details Page Loaded Successfully");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,250);");
			screenshot("account details page");
		} catch (Exception e) {
			System.out.println("Account Details Page not loaded"+e);
		}
		
	}
    
    public void invalidCred(String s1, String s2) 
    {
    	sendkey(Xpath.username(),s1);
		sendkey(Xpath.password(),s2);
		screenshot("Invalid Credentails");
    }
    public void invalidLogin()
    {
    	click(Xpath.submitButton());
    }
    public void errorMessages() throws Exception
    {
    	Thread.sleep(3000);
    	screenshot("Error Message");
    	String ErrMessage = getText(Xpath.errorText());
    	System.out.println("Error message : " +ErrMessage);
    }
    public void regiButton()
    {
    	click(Xpath.registerIt());
    }
    public void registerDetails()
    {
    	sendkey(Xpath.registerFirst(),PropertyFile.getValue("RegisterFirst"));
    	sendkey(Xpath.registerLast(),PropertyFile.getValue("RegisterLast"));
    	sendkey(Xpath.registerPassword(),PropertyFile.getValue("RegisterPassword"));
    	sendkey(Xpath.registerCPassword(),PropertyFile.getValue("RegisterPassword"));
    	sendkey(Xpath.registerEmail(),PropertyFile.getValue("RegisterEmail"));
    	sendkey(Xpath.registerPhone(),PropertyFile.getValue("RegisterPhno"));
    	sendkey(Xpath.registerDOB(),PropertyFile.getValue("RegisterDOB"));
    	Select dropdown = new Select(driver.findElement(By.id("gender")));
		dropdown.selectByIndex(1);
    	sendkey(Xpath.registerAddress(),PropertyFile.getValue("RegisterAddress"));
    	sendkey(Xpath.registerCity(),PropertyFile.getValue("RegisterCity"));
    	sendkey(Xpath.registerState(),PropertyFile.getValue("RegisterState"));
    	sendkey(Xpath.registerZipcode(),PropertyFile.getValue("RegisterZipcode"));
    	Select dropdown1 = new Select(driver.findElement(By.id("acctype")));
		dropdown1.selectByIndex(2);
    	sendkey(Xpath.registerPin(),PropertyFile.getValue("RegisterPin"));
    	sendkey(Xpath.registerCPin(),PropertyFile.getValue("RegisterPin"));
    	screenshot("register Details");
    }
    public void regiConfirmButton() throws Exception
    {
    	Thread.sleep(3000);
    	click(Xpath.submitButton());
    }
    public void registerError() throws Exception
    {
    	Thread.sleep(3000);
    	screenshot("register Error");
    	String ErrMessage = getText(Xpath.errorRegister());
    	System.out.println("Error message : " +ErrMessage);
    }
    

}
