package Elements;

public class Xpath 
{
	public static String username()
	{
		String s1 = "//input[@id='accno']";
		return s1;	
	}
	public static String password()
	{
		String s1 = "//input[@id='pass']";
		return s1;	
	}
	public static String submitButton()
	{
		String s1 = "//input[@id='submitButton']";
		return s1;	
	}
	public static String accPin()
	{
		String s1 = "//input[@id='accpin']";
		return s1;	
	}
	public static String welcomText()
	{
		String s1 = "(//tr/td/strong)[1]";
		return s1;	
	}
	public static String signOutButton()
	{
		String s1 = "//a[text()='Sign Out']";
		return s1;	
	}
	public static String fundTabButton()
	{
		String s1 = "//a[text()='Fund Transfers']";
		return s1;	
	}
	public static String reciverbankName()
	{
		String s1 = "//input[@name='rbname']";
		return s1;	
	}
	public static String reciverName()
	{
		String s1 = "//input[@name='rname']";
		return s1;	
	}
	public static String reciverAccnt()
	{
		String s1 = "//input[@name='accno']";
		return s1;	
	}
	public static String swiftNumber()
	{
		String s1 = "//input[@name='swift']";
		return s1;	
	}
	public static String fundAmount()
	{
		String s1 = "//input[@name='amt']";
		return s1;	
	}
	public static String dateTransfer()
	{
		String s1 = "//input[@name='dot']";
		return s1;	
	}
	public static String fundDescription()
	{
		String s1 = "//textarea[@name='desc']";
		return s1;	
	}
	public static String fundToken()
	{
		String s1 = "//input[@name='token']";
		return s1;	
	}
	public static String summaryTab()
	{
		String s1 = "//a[text()='Account Summary']";
		return s1;	
	}
	public static String statementTab()
	{
		String s1 = "//a[text()='Account Statement']";
		return s1;	
	}
	public static String statementColumn()
	{
		String s1 = "/html/body/table/tbody/tr[3]/td[2]/table/tbody/tr/td/table/tbody/tr[1]/th";
		return s1;	
	}
	public static String statementRow()
	{
		String s1 = "/html/body/table/tbody/tr[3]/td[2]/table/tbody/tr/td/table/tbody/tr";
		return s1;	
	}
	public static String rowText()
	{
		String s1 = "/html/body/table/tbody/tr[3]/td[2]/table/tbody/tr/td/table/tbody/tr[3]/td[3]";
		return s1;	
	}
	public static String AccountDetailsTab()
	{
		String s1 = "//a[text()='Account Details']";
		return s1;	
	}
	public static String AccountDetailsText()
	{
		String s1 = "//tr[@id='listTableHeader']/th";
		return s1;	
	}
	public static String errorText()
	{
		String s1 = "//div[@class='errorMessage']";
		return s1;	
	}
	
	public static String errorRegister()
	{
		String s1 = "//body";
		return s1;	
	}
	
	public static String registerIt()
	{
		String s1 = "//a[text()='Register it Now']";
		return s1;
	}
	public static String registerFirst()
	{
		String s1 = "//input[@name='firstname']";
		return s1;
	}
	public static String registerLast()
	{
		String s1 = "//input[@name='lastname']";
		return s1;
	}
	public static String registerPassword()
	{
		String s1 = "//input[@name='password']";
		return s1;
	}
	public static String registerCPassword()
	{
		String s1 = "//input[@name='cpassword']";
		return s1;
	}
	public static String registerEmail()
	{
		String s1 = "//input[@name='email']";
		return s1;
	}
	public static String registerPhone()
	{
		String s1 = "//input[@name='phone']";
		return s1;
	}
	public static String registerDOB()
	{
		String s1 = "//input[@name='dob']";
		return s1;
	}
	public static String registerAddress()
	{
		String s1 = "//textarea[@name='address']";
		return s1;
	}
	public static String registerCity()
	{
		String s1 = "//input[@name='city']";
		return s1;
	}
	public static String registerState()
	{
		String s1 = "//input[@name='state']";
		return s1;
	}
	public static String registerZipcode()
	{
		String s1 = "//input[@name='zipcode']";
		return s1;
	}
	public static String registerPin()
	{
		String s1 = "//input[@name='pin']";
		return s1;
	}
	public static String registerCPin()
	{
		String s1 = "//input[@name='cpin']";
		return s1;
	}



}
